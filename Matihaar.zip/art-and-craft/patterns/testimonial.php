<?php
/**
 * Title: Testimonial
 * Slug: art-and-craft/testimonial
 * Categories: art-and-craft, testimonial
 */
?>

<!-- wp:group {"className":"testimonial-section","style":{"spacing":{"padding":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"75%"}} -->
<div class="wp-block-group testimonial-section" style="padding-top:0;padding-bottom:0"><!-- wp:spacer {"height":"35px"} -->
<div style="height:35px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"className":"sec-head","layout":{"type":"default"}} -->
<div class="wp-block-group sec-head">
<!-- wp:heading {"textAlign":"center","level":6,"className":"sec-shot-heading","style":{"typography":{"fontStyle":"normal","fontWeight":"700","fontSize":"14px"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"border":{"radius":"30px"},"spacing":{"padding":{"left":"var:preset|spacing|40","right":"var:preset|spacing|40","top":"2px","bottom":"2px"}}},"backgroundColor":"primary","textColor":"white"} -->
	<h6 class="wp-block-heading has-text-align-center sec-shot-heading has-white-color has-primary-background-color has-text-color has-background has-link-color" style="border-radius:30px;padding-top:2px;padding-right:var(--wp--preset--spacing--40);padding-bottom:2px;padding-left:var(--wp--preset--spacing--40);font-size:14px;font-style:normal;font-weight:700"><?php esc_html_e('Our Testimonials','art-and-craft'); ?></h6>
	<!-- /wp:heading -->

	<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"25px","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<h2 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:25px;font-style:normal;font-weight:800"><?php esc_html_e('What Our Clients Says About Us','art-and-craft'); ?></h2>
	<!-- /wp:heading --></div>
	<!-- /wp:group -->

<!-- wp:group {"className":"art-and-craft-testimonial-swiper","style":{"spacing":{"padding":{"bottom":"var:preset|spacing|60","right":"0px","left":"0px"}}},"layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group art-and-craft-testimonial-swiper" style="padding-right:0px;padding-bottom:var(--wp--preset--spacing--60);padding-left:0px"><!-- wp:group {"className":"art-and-craft-testimonial-swiper-holder swiper-wrapper","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group art-and-craft-testimonial-swiper-holder swiper-wrapper" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":" swiper-slide","layout":{"type":"default"}} -->
<div class="wp-block-group  swiper-slide"><!-- wp:group {"className":"tstimonial-box","style":{"spacing":{"padding":{"top":"50px","bottom":"50px","left":"20px","right":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group tstimonial-box" style="padding-top:50px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:image {"id":9,"sizeSlug":"full","linkDestination":"none","align":"center","className":"testimonail-main-img","style":{"border":{"radius":"50%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border testimonail-main-img"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/testimonial1.png'); ?>" alt="" class="wp-image-9" style="border-radius:50%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"600","fontSize":"20px"}}} -->
<h6 class="wp-block-heading has-text-align-center" style="font-size:20px;font-style:normal;font-weight:600;text-transform:capitalize"><?php esc_html_e('Ava Mitchell','art-and-craft'); ?></h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"typography":{"fontSize":"16px"}}} -->
<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper ultricies urna et imperdiet et pulvinar in ullamcorper. Cursus tellus tincidunt elementum…','art-and-craft'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":113,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
<figure class="wp-block-image aligncenter size-full" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/star.png'); ?>" alt="" class="wp-image-113"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":" swiper-slide","layout":{"type":"default"}} -->
<div class="wp-block-group  swiper-slide"><!-- wp:group {"className":"tstimonial-box","style":{"spacing":{"padding":{"top":"50px","bottom":"50px","left":"20px","right":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group tstimonial-box" style="padding-top:50px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:image {"id":34,"sizeSlug":"full","linkDestination":"none","align":"center","className":"testimonail-main-img","style":{"border":{"radius":"50%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border testimonail-main-img"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/testimonial2.png'); ?>" alt="" class="wp-image-34" style="border-radius:50%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"600","fontSize":"20px"}}} -->
<h6 class="wp-block-heading has-text-align-center" style="font-size:20px;font-style:normal;font-weight:600;text-transform:capitalize"><?php esc_html_e('Rahul Desai','art-and-craft'); ?></h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"typography":{"fontSize":"16px"}}} -->
<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper ultricies urna et imperdiet et pulvinar in ullamcorper. Cursus tellus tincidunt elementum…','art-and-craft'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":113,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
<figure class="wp-block-image aligncenter size-full" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/star.png'); ?>" alt="" class="wp-image-113"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":" swiper-slide","layout":{"type":"default"}} -->
<div class="wp-block-group  swiper-slide"><!-- wp:group {"className":"tstimonial-box","style":{"spacing":{"padding":{"top":"50px","bottom":"50px","left":"20px","right":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group tstimonial-box" style="padding-top:50px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:image {"id":38,"sizeSlug":"full","linkDestination":"none","align":"center","className":"testimonail-main-img","style":{"border":{"radius":"50%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border testimonail-main-img"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/testimonial3.png'); ?>" alt="" class="wp-image-38" style="border-radius:50%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"600","fontSize":"20px"}}} -->
<h6 class="wp-block-heading has-text-align-center" style="font-size:20px;font-style:normal;font-weight:600;text-transform:capitalize"><?php esc_html_e('Claire Benson','art-and-craft'); ?></h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"typography":{"fontSize":"16px"}}} -->
<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper ultricies urna et imperdiet et pulvinar in ullamcorper. Cursus tellus tincidunt elementum…','art-and-craft'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":113,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
<figure class="wp-block-image aligncenter size-full" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/star.png'); ?>" alt="" class="wp-image-113"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":" swiper-slide","layout":{"type":"default"}} -->
<div class="wp-block-group  swiper-slide"><!-- wp:group {"className":"tstimonial-box","style":{"spacing":{"padding":{"top":"50px","bottom":"50px","left":"20px","right":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group tstimonial-box" style="padding-top:50px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:image {"id":40,"sizeSlug":"full","linkDestination":"none","align":"center","className":"testimonail-main-img","style":{"border":{"radius":"50%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border testimonail-main-img"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/testimonial4.png'); ?>" alt="" class="wp-image-40" style="border-radius:50%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"600","fontSize":"20px"}}} -->
<h6 class="wp-block-heading has-text-align-center" style="font-size:20px;font-style:normal;font-weight:600;text-transform:capitalize"><?php esc_html_e('Liam Chen','art-and-craft'); ?></h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"typography":{"fontSize":"16px"}}} -->
<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper ultricies urna et imperdiet et pulvinar in ullamcorper. Cursus tellus tincidunt elementum…','art-and-craft'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":113,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
<figure class="wp-block-image aligncenter size-full" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/star.png'); ?>" alt="" class="wp-image-113"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":" swiper-slide","layout":{"type":"default"}} -->
<div class="wp-block-group  swiper-slide"><!-- wp:group {"className":"tstimonial-box","style":{"spacing":{"padding":{"top":"50px","bottom":"50px","left":"20px","right":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group tstimonial-box" style="padding-top:50px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:image {"id":40,"sizeSlug":"full","linkDestination":"none","align":"center","className":"testimonail-main-img","style":{"border":{"radius":"50%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border testimonail-main-img"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/testimonial4.png'); ?>" alt="" class="wp-image-40" style="border-radius:50%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"600","fontSize":"20px"}}} -->
<h6 class="wp-block-heading has-text-align-center" style="font-size:20px;font-style:normal;font-weight:600;text-transform:capitalize"><?php esc_html_e('Liam Chen','art-and-craft'); ?></h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"typography":{"fontSize":"16px"}}} -->
<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper ultricies urna et imperdiet et pulvinar in ullamcorper. Cursus tellus tincidunt elementum…','art-and-craft'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":113,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
<figure class="wp-block-image aligncenter size-full" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/star.png'); ?>" alt="" class="wp-image-113"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"art-and-craft-testimonial-swiper-controls","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group art-and-craft-testimonial-swiper-controls" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:html -->
<div class="art-and-craft-testimonial-swiper-button-prev swiper-button-prev"></div>
 <div class="art-and-craft-testimonial-swiper-button-next swiper-button-next"></div>
 <div class="art-and-craft-testimonial-pagination"></div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->